package com.web.model;


public class ChatMessage {
    private String from;
    private String content;
}
